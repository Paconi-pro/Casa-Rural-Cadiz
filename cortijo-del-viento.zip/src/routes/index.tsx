import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Cortijo del Viento — Casa rural en Cádiz" },
      { name: "description", content: "Refugio rural de lujo en el corazón de Cádiz. Naturaleza, piscina, vistas al mar y autenticidad andaluza." },
    ],
  }),
});

const ALUMNO = "[Tu Nombre]";

const features = [
  { icon: "🛏", title: "4 habitaciones", desc: "Suites con vigas de madera, lino natural y vistas al campo." },
  { icon: "🌊", title: "Piscina infinita", desc: "Climatizada, integrada en el paisaje gaditano." },
  { icon: "📡", title: "WiFi de fibra", desc: "Conectividad de alta velocidad en toda la finca." },
  { icon: "🔥", title: "Barbacoa de leña", desc: "Porche cubierto con horno de leña y mesa para 12." },
  { icon: "🏖", title: "A 10 min del mar", desc: "Playas vírgenes de la Costa de la Luz a tu alcance." },
  { icon: "🌿", title: "Entorno protegido", desc: "Rodeada de olivos centenarios y dehesa." },
];

const gallery = [
  { src: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=1200&q=80", alt: "Salón con chimenea" },
  { src: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=1200&q=80", alt: "Habitación principal" },
  { src: "https://images.unsplash.com/photo-1615874959474-d609969a20ed?w=1200&q=80", alt: "Piscina exterior" },
  { src: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1200&q=80", alt: "Fachada al atardecer" },
  { src: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80", alt: "Cocina rústica" },
  { src: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=1200&q=80", alt: "Patio andaluz" },
  { src: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80", alt: "Dormitorio con vistas" },
  { src: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=80", alt: "Vista aérea de la finca" },
];

const reviews = [
  { name: "María González", origin: "Madrid", stars: 5, text: "El silencio, la luz y los detalles. Volvimos a casa con el alma descansada. Una experiencia de otro nivel." },
  { name: "Carlos Romero", origin: "Barcelona", stars: 5, text: "Los anfitriones cuidan cada rincón. La piscina al amanecer es un recuerdo que no se borra." },
  { name: "Lucía Pérez", origin: "Sevilla", stars: 5, text: "Perfecta para familias y para escapar del ruido. El desayuno con productos locales es sublime." },
  { name: "James Whitaker", origin: "Londres", stars: 5, text: "A hidden Andalusian jewel. Worth every mile. We're already planning to return next spring." },
];

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("animate-float-up");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15 },
    );
    els.forEach((el) => {
      el.style.opacity = "0";
      io.observe(el);
    });
    return () => io.disconnect();
  }, []);
}

function Index() {
  useReveal();
  const [scrolled, setScrolled] = useState(false);
  const [lightbox, setLightbox] = useState<number | null>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      if (heroRef.current) {
        const y = window.scrollY * 0.4;
        heroRef.current.style.transform = `translate3d(0, ${y}px, 0)`;
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="bg-background text-foreground min-h-screen overflow-x-hidden">
      {/* Nav */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? "bg-background/85 backdrop-blur-xl shadow-sm py-3" : "bg-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-2 group">
            <span className="w-9 h-9 rounded-full flex items-center justify-center text-sm" style={{ background: "var(--gradient-warm)", color: "white" }}>
              CV
            </span>
            <span className={`font-display text-xl tracking-wide transition-colors ${scrolled ? "text-foreground" : "text-white"}`}>
              Cortijo del Viento
            </span>
          </a>
          <nav className="hidden md:flex gap-8 text-sm font-medium">
            {[
              ["Esencia", "#esencia"],
              ["Casa", "#caracteristicas"],
              ["Galería", "#galeria"],
              ["Ubicación", "#mapa"],
              ["Reseñas", "#resenas"],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                className={`relative transition-colors hover:opacity-80 ${scrolled ? "text-foreground" : "text-white"}`}
              >
                {label}
              </a>
            ))}
          </nav>
          <a
            href="#contacto"
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium text-white transition-all hover:scale-105"
            style={{ background: "var(--gradient-warm)", boxShadow: "var(--shadow-glow)" }}
          >
            Reservar
          </a>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="relative h-screen min-h-[640px] overflow-hidden">
        <div ref={heroRef} className="absolute inset-0 will-change-transform">
          <img
            src="https://images.unsplash.com/photo-1542718610-a1d656d1884c?w=2400&q=85"
            alt="Cortijo andaluz al atardecer"
            className="w-full h-[120%] object-cover animate-ken-burns"
          />
          <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/70" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center items-center text-center px-6 text-white">
          <span className="text-xs tracking-[0.4em] uppercase mb-6 opacity-80 animate-float-up" style={{ animationDelay: "0.2s" }}>
            Casa Rural · Cádiz · Desde 1892
          </span>
          <h1
            className="font-display text-6xl md:text-8xl lg:text-9xl leading-[0.95] max-w-5xl animate-float-up"
            style={{ animationDelay: "0.4s" }}
          >
            Donde el viento
            <br />
            <em className="italic" style={{ color: "var(--gold)" }}>cuenta historias</em>
          </h1>
          <p className="mt-8 max-w-xl text-lg opacity-90 font-light animate-float-up" style={{ animationDelay: "0.6s" }}>
            Casa rural de pruebas — actividad con <span className="font-medium">{ALUMNO}</span>.
            Un refugio entre olivos, mar y silencio en el corazón de Andalucía.
          </p>
          <div className="mt-10 flex flex-wrap gap-4 justify-center animate-float-up" style={{ animationDelay: "0.8s" }}>
            <a href="#contacto" className="px-8 py-4 rounded-full font-medium text-white transition-all hover:scale-105"
               style={{ background: "var(--gradient-warm)", boxShadow: "var(--shadow-glow)" }}>
              Reservar estancia
            </a>
            <a href="#galeria" className="px-8 py-4 rounded-full font-medium border border-white/40 backdrop-blur-md hover:bg-white/10 transition-all">
              Ver la casa
            </a>
          </div>

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-xs tracking-[0.3em] uppercase opacity-70 flex flex-col items-center gap-2">
            <span>Descubrir</span>
            <div className="w-px h-12 bg-white/60 animate-pulse" />
          </div>
        </div>
      </section>

      {/* Esencia */}
      <section id="esencia" className="py-32 px-6 max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div data-reveal>
            <span className="text-xs tracking-[0.4em] uppercase" style={{ color: "var(--terracotta)" }}>La esencia</span>
            <h2 className="font-display text-5xl md:text-6xl mt-4 leading-tight">
              Una casa con <em className="italic" style={{ color: "var(--terracotta-deep)" }}>alma andaluza</em>.
            </h2>
            <p className="mt-6 text-lg text-foreground/70 leading-relaxed font-light">
              Restaurada con piedra original, vigas de castaño y la calma de quienes saben
              que el verdadero lujo es el tiempo. Aquí no hay prisa, solo amaneceres lentos
              y atardeceres que se quedan contigo.
            </p>
            <div className="mt-10 grid grid-cols-3 gap-6">
              {[["130", "años"], ["8", "huéspedes"], ["12", "ha de finca"]].map(([n, l]) => (
                <div key={l}>
                  <div className="font-display text-4xl" style={{ color: "var(--terracotta)" }}>{n}</div>
                  <div className="text-xs uppercase tracking-widest text-foreground/60 mt-1">{l}</div>
                </div>
              ))}
            </div>
          </div>
          <div data-reveal className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden" style={{ boxShadow: "var(--shadow-soft)" }}>
              <img src="https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=900&q=85"
                   alt="Detalle del cortijo" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-8 -left-8 w-48 h-48 rounded-2xl overflow-hidden hidden md:block" style={{ boxShadow: "var(--shadow-glow)" }}>
              <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&q=85"
                   alt="Detalle interior" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Características */}
      <section id="caracteristicas" className="py-32 px-6" style={{ background: "var(--cream)" }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto" data-reveal>
            <span className="text-xs tracking-[0.4em] uppercase" style={{ color: "var(--terracotta)" }}>La casa</span>
            <h2 className="font-display text-5xl md:text-6xl mt-4">Cada detalle, pensado.</h2>
          </div>
          <div className="mt-20 grid md:grid-cols-2 lg:grid-cols-3 gap-px" style={{ background: "var(--sand)" }}>
            {features.map((f, i) => (
              <div
                key={f.title}
                data-reveal
                className="bg-background p-10 group hover:bg-card transition-all duration-500"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="text-4xl mb-6 transition-transform duration-500 group-hover:scale-110 group-hover:-translate-y-1">{f.icon}</div>
                <h3 className="font-display text-2xl">{f.title}</h3>
                <p className="mt-3 text-foreground/65 leading-relaxed font-light">{f.desc}</p>
                <div className="mt-6 h-px w-12 transition-all duration-500 group-hover:w-24" style={{ background: "var(--terracotta)" }} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Galería */}
      <section id="galeria" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-16" data-reveal>
          <div>
            <span className="text-xs tracking-[0.4em] uppercase" style={{ color: "var(--terracotta)" }}>Galería</span>
            <h2 className="font-display text-5xl md:text-6xl mt-4">Un viaje visual.</h2>
          </div>
          <p className="max-w-md text-foreground/70 font-light">
            Pulsa cualquier imagen para ampliarla y dejarte llevar por la luz de Cádiz.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {gallery.map((g, i) => (
            <button
              key={i}
              data-reveal
              onClick={() => setLightbox(i)}
              className={`relative overflow-hidden rounded-xl group ${i % 5 === 0 ? "col-span-2 row-span-2 aspect-square" : "aspect-square"}`}
              style={{ boxShadow: "var(--shadow-soft)" }}
            >
              <img
                src={g.src}
                alt={g.alt}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <span className="absolute bottom-4 left-4 text-white text-xs tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                {g.alt}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-6 animate-float-up"
          onClick={() => setLightbox(null)}
        >
          <img src={gallery[lightbox].src} alt={gallery[lightbox].alt} className="max-w-full max-h-full object-contain rounded-lg" />
          <button className="absolute top-6 right-6 text-white text-3xl" onClick={() => setLightbox(null)}>×</button>
        </div>
      )}

      {/* Mapa */}
      <section id="mapa" className="py-32 px-6" style={{ background: "var(--olive-deep)", color: "white" }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div data-reveal>
              <span className="text-xs tracking-[0.4em] uppercase" style={{ color: "var(--gold)" }}>Ubicación</span>
              <h2 className="font-display text-5xl md:text-6xl mt-4 leading-tight">
                En el sur del <em className="italic" style={{ color: "var(--gold)" }}>sur</em>.
              </h2>
              <p className="mt-6 text-lg text-white/80 font-light leading-relaxed">
                Entre Vejer de la Frontera y la costa atlántica. A 1h de Sevilla,
                40 min del aeropuerto de Jerez y un suspiro de las mejores playas
                de Europa.
              </p>
              <ul className="mt-8 space-y-3 text-white/90">
                {["Playa de Bolonia · 18 km", "Tarifa · 25 km", "Cádiz capital · 45 km", "Doñana · 1h 30 min"].map((p) => (
                  <li key={p} className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--gold)" }} />
                    {p}
                  </li>
                ))}
              </ul>
            </div>
            <div data-reveal className="rounded-2xl overflow-hidden h-[500px]" style={{ boxShadow: "var(--shadow-glow)" }}>
              <iframe
                title="Ubicación en Cádiz"
                src="https://www.google.com/maps?q=Vejer+de+la+Frontera,C%C3%A1diz&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0, filter: "saturate(0.9)" }}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Reseñas */}
      <section id="resenas" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-20" data-reveal>
          <span className="text-xs tracking-[0.4em] uppercase" style={{ color: "var(--terracotta)" }}>Voces</span>
          <h2 className="font-display text-5xl md:text-6xl mt-4">Lo que cuentan quienes han vuelto.</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((r) => (
            <blockquote
              key={r.name}
              data-reveal
              className="p-10 rounded-2xl bg-card border border-border/50 relative"
              style={{ boxShadow: "var(--shadow-soft)" }}
            >
              <span className="absolute top-4 left-6 font-display text-7xl leading-none" style={{ color: "var(--terracotta)", opacity: 0.2 }}>"</span>
              <div className="text-sm tracking-widest" style={{ color: "var(--gold)" }}>{"★".repeat(r.stars)}</div>
              <p className="mt-4 text-lg font-light italic text-foreground/85 leading-relaxed">{r.text}</p>
              <footer className="mt-6 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-medium" style={{ background: "var(--gradient-warm)" }}>
                  {r.name.charAt(0)}
                </div>
                <div>
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-foreground/60 uppercase tracking-wider">{r.origin}</div>
                </div>
              </footer>
            </blockquote>
          ))}
        </div>
      </section>

      {/* CTA / Contacto */}
      <section id="contacto" className="relative py-32 px-6 overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?w=2000&q=80"
               alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, oklch(0.28 0.05 110 / 0.85), oklch(0.48 0.14 38 / 0.75))" }} />
        </div>
        <div className="relative max-w-3xl mx-auto text-center text-white" data-reveal>
          <span className="text-xs tracking-[0.4em] uppercase opacity-80">Reservas</span>
          <h2 className="font-display text-5xl md:text-7xl mt-4 leading-tight">
            ¿Te esperamos?
          </h2>
          <p className="mt-6 text-lg font-light opacity-90 max-w-xl mx-auto">
            Escríbenos y diseñamos tu estancia a medida. Respondemos en menos de 24 horas.
          </p>
          <div className="mt-12 flex flex-wrap gap-4 justify-center">
            <a href="mailto:hola@cortijodelviento.example"
               className="inline-flex items-center gap-3 px-8 py-4 rounded-full font-medium bg-white text-foreground hover:scale-105 transition-transform"
               style={{ boxShadow: "var(--shadow-glow)" }}>
              ✉ Contactar
            </a>
            <a href="https://wa.me/34600000000" target="_blank" rel="noreferrer"
               className="inline-flex items-center gap-3 px-8 py-4 rounded-full font-medium text-white hover:scale-105 transition-transform"
               style={{ background: "#25d366", boxShadow: "var(--shadow-glow)" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 2C6.477 2 2 6.477 2 12c0 1.79.474 3.47 1.305 4.926L2 22l5.227-1.367A9.97 9.97 0 0012 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/></svg>
              WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-6" style={{ background: "var(--olive-deep)", color: "rgba(255,255,255,0.85)" }}>
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-10">
          <div>
            <div className="font-display text-2xl text-white">Cortijo del Viento</div>
            <p className="mt-3 text-sm opacity-70 font-light leading-relaxed">
              Casa rural de pruebas — actividad con {ALUMNO}.
            </p>
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest opacity-60 mb-4">Navegar</div>
            <ul className="space-y-2 text-sm">
              <li><a href="#caracteristicas" className="hover:text-white transition-colors">La casa</a></li>
              <li><a href="#galeria" className="hover:text-white transition-colors">Galería</a></li>
              <li><a href="#resenas" className="hover:text-white transition-colors">Reseñas</a></li>
              <li><a href="#contacto" className="hover:text-white transition-colors">Contacto</a></li>
            </ul>
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest opacity-60 mb-4">Legal</div>
            <ul className="space-y-2 text-sm">
              <li><a href="/politica-privacidad.md" className="hover:text-white transition-colors">Política de privacidad</a></li>
              <li><a href="/aviso-legal.md" className="hover:text-white transition-colors">Aviso legal</a></li>
              <li><a href="/cookies.md" className="hover:text-white transition-colors">Cookies</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/10 text-xs opacity-60 flex flex-wrap justify-between gap-4">
          <span>© {new Date().getFullYear()} Cortijo del Viento. Todos los derechos reservados.</span>
          <span>Hecho con cariño en Cádiz</span>
        </div>
      </footer>
    </div>
  );
}
